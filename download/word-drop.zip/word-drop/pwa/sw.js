const CACHE_NAME = 'word-drop-pwa-v20';
const STATIC_ASSETS = [
    './index.html',
    './style.css',
    './effects.js',
    './app.js',
    './icon-192.png',
    './icon-512.png',
    './apple-touch-icon.png',
    './favicon-32x32.png',
    './favicon.ico',
    'https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Pacifico&family=Righteous&family=Boogaloo&family=Permanent+Marker&family=Playfair+Display:ital,wght@0,400;0,700;1,400&display=swap',
];

self.addEventListener( 'install', event => {
    event.waitUntil(
        caches.open( CACHE_NAME ).then( cache => cache.addAll( STATIC_ASSETS ) )
    );
    self.skipWaiting();
} );

self.addEventListener( 'activate', event => {
    event.waitUntil(
        caches.keys().then( keys =>
            Promise.all( keys.filter( k => k !== CACHE_NAME ).map( k => caches.delete( k ) ) )
        )
    );
    self.clients.claim();
} );

self.addEventListener( 'fetch', event => {
    // Network-first for API calls, cache-first for static assets
    const url = new URL( event.request.url );
    if ( url.pathname.includes( 'word-drop/v1' ) ) {
        event.respondWith( fetch( event.request ) );
        return;
    }
    event.respondWith(
        caches.match( event.request ).then( cached => cached || fetch( event.request ) )
    );
} );
