/**
 * Word Drop PWA — App JS
 *
 * Login-arkitektur kopieret fra Bane Status (virker).
 * POST /auth → { pin } → { success, token }
 * Token gemmes i sessionStorage — PIN forlader aldrig submitPin().
 */
( function () {
    'use strict';

    // --------------------------------------------------------
    // KONFIGURATION — læses fra <meta name="word-drop-api-base">
    // --------------------------------------------------------
    const BASE_URL = ( () => {
        const meta = document.querySelector( 'meta[name="word-drop-api-base"]' );
        const val  = meta?.getAttribute( 'content' )?.trim();
        if ( val ) return val.replace( /\/$/, '' );
        return window.location.origin;
    } )();

    const API = {
        auth:    BASE_URL + '/wp-json/word-drop/v1/auth',
        publish: BASE_URL + '/wp-json/word-drop/v1/publish',
        clear:   BASE_URL + '/wp-json/word-drop/v1/clear',
        status:  BASE_URL + '/wp-json/word-drop/v1/status',
    };

    const SESSION_KEY = 'wd_session';

    const FONTS = [
        { slug: 'bebas-neue',       label: 'Bebas Neue',       family: "'Bebas Neue', sans-serif" },
        { slug: 'pacifico',         label: 'Pacifico',         family: "'Pacifico', cursive" },
        { slug: 'righteous',        label: 'Righteous',        family: "'Righteous', sans-serif" },
        { slug: 'boogaloo',         label: 'Boogaloo',         family: "'Boogaloo', sans-serif" },
        { slug: 'permanent-marker', label: 'Perm. Marker',     family: "'Permanent Marker', cursive" },
        { slug: 'playfair-display',  label: 'Playfair',         family: "'Playfair Display', serif" },
    ];

    const EFFECTS = [
        { slug: 'fade-gradient',  label: 'Fade',   icon: '🌅' },
        { slug: 'pixel-assemble', label: 'Pixels', icon: '⚡' },
        { slug: 'draw-stroke',    label: 'Draw',   icon: '✏️' },
        { slug: 'glitch-burst',   label: 'Glitch', icon: '🌀' },
        { slug: 'liquid-rise',    label: 'Liquid', icon: '🌊' },
        { slug: 'shadow-drift',   label: 'Shadow', icon: '🌑' },
    ];

    // --------------------------------------------------------
    // STATE
    // --------------------------------------------------------
    const state = {
        pin:             '',
        isLoading:       false,
        selectedFont:    'bebas-neue',
        selectedEffect:  'fade-gradient',
        selectedDur:     0,
        selectedSize:    'medium',
        opacity:         0.6,
        gradStart:       '#ffffff',
        gradEnd:         '#00e5ff',
    };

    // --------------------------------------------------------
    // DOM
    // --------------------------------------------------------
    const $ = id => document.getElementById( id );
    const dom = {
        screenLogin:    $( 'screen-login' ),
        screenComposer: $( 'screen-composer' ),
        pinDots:        document.querySelectorAll( '.pin-dot' ),
        loginError:     $( 'login-error' ),
        loginErrorText: $( 'login-error-text' ),
        keypadBtns:     document.querySelectorAll( '.keypad__btn[data-digit]' ),
        keypadDelete:   $( 'keypad-delete' ),
        overlayStatus:  $( 'overlay-status-label' ),
        btnLogout:      $( 'btn-logout' ),
        overlayText:    $( 'overlay-text' ),
        charCount:      $( 'char-count' ),
        fontGrid:       $( 'font-grid' ),
        effectGrid:     $( 'effect-grid' ),
        gradStart:      $( 'grad-start' ),
        gradEnd:        $( 'grad-end' ),
        gradPreview:    $( 'grad-preview' ),
        durBtns:        document.querySelectorAll( '.dur-btn[data-dur]' ),
        sizeBtns:       document.querySelectorAll( '.dur-btn[data-size]' ),
        opacitySlider:  $( 'opacity-slider' ),
        opacityValue:   $( 'opacity-value' ),
        publishBtn:     $( 'publish-btn' ),
        clearBtn:       $( 'clear-btn' ),
        feedback:       $( 'save-feedback' ),
        feedbackText:   $( 'save-feedback-text' ),
        previewContainer: $( 'preview-container' ),
        previewCanvas:    $( 'preview-canvas' ),
        previewTextEl:    $( 'preview-text-el' ),
        previewReplay:    $( 'preview-replay' ),
    };

    // --------------------------------------------------------
    // INIT
    // --------------------------------------------------------
    function init() {
        if ( 'serviceWorker' in navigator ) {
            navigator.serviceWorker.register( './sw.js' ).catch(
                e => console.warn( '[WD] SW:', e )
            );
        }

        buildFontGrid();
        buildEffectGrid();
        bindEvents();
        updateGradientPreview();
        updateSliderFill( dom.opacitySlider );
        // NOTE: preview is started by showComposer(), not here —
        // running it during init would waste cycles on the hidden screen
        // and block the real first preview via the previewRunning guard.

        const session = loadSession();
        if ( session ) {
            showComposer();
        } else {
            showLogin();
        }
    }

    // --------------------------------------------------------
    // SCREENS
    // --------------------------------------------------------
    function showLogin() {
        dom.screenComposer.classList.remove( 'screen--active' );
        dom.screenLogin.classList.add( 'screen--active' );
        resetPin();
        hideLoginError();
    }

    function showComposer() {
        dom.screenLogin.classList.remove( 'screen--active' );
        dom.screenComposer.classList.add( 'screen--active' );
        pollStatus();

        // Reset any preview state left over from init() running on hidden screen
        clearTimeout( previewDebounce );
        clearTimeout( _previewSafetyTimer );
        previewRunning = false;
        if ( previewCtx ) window.WordDropEffects?.clearAll( previewCtx );

        // Small delay so the container has layout before effects measure dimensions
        setTimeout( () => schedulePreview( true ), 150 );
    }

    // --------------------------------------------------------
    // SESSION — token only, never PIN
    // --------------------------------------------------------
    function saveSession( token, expires ) {
        try {
            sessionStorage.setItem( SESSION_KEY, JSON.stringify( { token, expires } ) );
        } catch ( e ) { /* ignore */ }
    }

    function loadSession() {
        try {
            const raw = sessionStorage.getItem( SESSION_KEY );
            if ( ! raw ) return null;
            const s = JSON.parse( raw );
            // expires is a unix timestamp in seconds
            if ( Date.now() > s.expires * 1000 ) {
                sessionStorage.removeItem( SESSION_KEY );
                return null;
            }
            return s;
        } catch ( e ) { return null; }
    }

    function clearSession() {
        try { sessionStorage.removeItem( SESSION_KEY ); } catch ( e ) { /* ignore */ }
    }

    function getToken() {
        const s = loadSession();
        return s ? s.token : null;
    }

    // --------------------------------------------------------
    // LOGIN — kopieret fra Bane Status
    // --------------------------------------------------------
    function handleDigit( digit ) {
        if ( state.pin.length >= 4 ) return;
        state.pin += digit;
        updatePinDots();
        if ( state.pin.length === 4 ) setTimeout( submitPin, 120 );
    }

    function handleDelete() {
        if ( ! state.pin.length ) return;
        state.pin = state.pin.slice( 0, -1 );
        updatePinDots();
        hideLoginError();
    }

    async function submitPin() {
        const pin = state.pin;
        resetPin(); // Clear immediately — PIN never leaves this function

        try {
            const res = await fetch( API.auth, {
                method:  'POST',
                headers: { 'Content-Type': 'application/json' },
                body:    JSON.stringify( { pin } ),
                signal:  AbortSignal.timeout( 10000 ),
            } );

            const data = await res.json();

            if ( res.status === 429 ) {
                showLoginError( 'Too many attempts — try again shortly' );
                return;
            }

            if ( ! res.ok || ! data.success ) {
                showLoginError( data.message || 'Wrong PIN' );
                return;
            }

            // Success — decode expires from token payload
            const payload = data.token.split( '.' )[ 0 ];
            const decoded = atob( payload );
            const expires = parseInt( decoded.split( '|' )[ 0 ], 10 );

            saveSession( data.token, expires );
            showComposer();

        } catch ( e ) {
            showLoginError( e.name === 'AbortError' ? 'Timeout — try again' : 'Network error' );
        }
    }

    // --------------------------------------------------------
    // STATUS POLL
    // --------------------------------------------------------
    let pollTimer = null;

    function pollStatus() {
        doStatusPoll();
        clearInterval( pollTimer );
        pollTimer = setInterval( doStatusPoll, 5000 );
    }

    async function doStatusPoll() {
        try {
            const res  = await fetch( API.status, { cache: 'no-store' } );
            const data = await res.json();
            if ( data.active ) {
                const truncated = data.text
                    ? data.text.substring( 0, 18 ) + ( data.text.length > 18 ? '…' : '' )
                    : 'ACTIVE';
                dom.overlayStatus.textContent = truncated.toUpperCase();
                dom.overlayStatus.className = 'app-header__status app-header__status--active';
                dom.clearBtn.hidden = false;
            } else {
                dom.overlayStatus.textContent = 'NO OVERLAY';
                dom.overlayStatus.className = 'app-header__status';
                dom.clearBtn.hidden = true;
            }
        } catch ( e ) { /* ignore */ }
    }

    // --------------------------------------------------------
    // PUBLISH
    // --------------------------------------------------------
    async function handlePublish() {
        const text = dom.overlayText.value.trim();
        if ( ! text ) { showFeedback( 'Enter some text first', 'error' ); return; }

        const token = getToken();
        if ( ! token ) { logout(); return; }

        // Phase 1: Sender...
        setLoading( true );
        showFeedback( 'Sending…', 'sending' );

        try {
            const res = await fetch( API.publish, {
                method:  'POST',
                headers: {
                    'Content-Type':  'application/json',
                    'Authorization': 'Bearer ' + token,
                },
                body: JSON.stringify( {
                    text,
                    font:     state.selectedFont,
                    effect:   state.selectedEffect,
                    duration: state.selectedDur,
                    size:     state.selectedSize,
                    opacity:  state.opacity,
                    gradient: state.gradStart + ',' + state.gradEnd,
                } ),
                signal: AbortSignal.timeout( 10000 ),
            } );

            const data = await res.json();

            if ( res.status === 401 ) {
                showFeedback( 'Session expired — please log in again', 'error' );
                setTimeout( logout, 1500 );
                return;
            }

            if ( ! res.ok || ! data.success ) {
                showFeedback( data.message || 'Publishing failed', 'error' );
                return;
            }

            // Phase 2: Live på site — with pulse animation
            showFeedback( '⚡ Live on your site!', 'success' );
            setTimeout( hideFeedback, 3500 );
            doStatusPoll();

        } catch ( e ) {
            showFeedback( e.name === 'AbortError' ? 'Timeout' : 'Network error', 'error' );
        } finally {
            setLoading( false );
        }
    }

    // --------------------------------------------------------
    // CLEAR
    // --------------------------------------------------------
    async function handleClear() {
        const token = getToken();
        if ( ! token ) { logout(); return; }

        dom.clearBtn.disabled = true;
        try {
            const res = await fetch( API.clear, {
                method:  'POST',
                headers: { 'Authorization': 'Bearer ' + token },
                signal:  AbortSignal.timeout( 10000 ),
            } );
            if ( res.status === 401 ) { logout(); return; }
            doStatusPoll();
            showFeedback( 'Overlay removed', 'success' );
            setTimeout( hideFeedback, 2000 );
        } catch ( e ) {
            showFeedback( 'Network error', 'error' );
        } finally {
            dom.clearBtn.disabled = false;
        }
    }

    // --------------------------------------------------------
    // UI BUILDERS
    // --------------------------------------------------------
    function buildFontGrid() {
        dom.fontGrid.innerHTML = '';
        FONTS.forEach( f => {
            const btn = document.createElement( 'button' );
            btn.className    = 'font-card' + ( f.slug === state.selectedFont ? ' selected' : '' );
            btn.dataset.slug = f.slug;
            btn.style.fontFamily = f.family;
            btn.textContent  = f.label;
            btn.addEventListener( 'click', () => {
                state.selectedFont = f.slug;
                document.querySelectorAll( '.font-card' ).forEach( c =>
                    c.classList.toggle( 'selected', c.dataset.slug === f.slug )
                );
                updateLivePreview();
            } );
            dom.fontGrid.appendChild( btn );
        } );
    }

    function buildEffectGrid() {
        dom.effectGrid.innerHTML = '';
        EFFECTS.forEach( e => {
            const btn = document.createElement( 'button' );
            btn.className    = 'effect-card' + ( e.slug === state.selectedEffect ? ' selected' : '' );
            btn.dataset.slug = e.slug;
            btn.innerHTML    = `<span class="effect-card__icon">${ e.icon }</span><span class="effect-card__label">${ e.label }</span>`;
            btn.addEventListener( 'click', () => {
                state.selectedEffect = e.slug;
                document.querySelectorAll( '.effect-card' ).forEach( c =>
                    c.classList.toggle( 'selected', c.dataset.slug === e.slug )
                );
                schedulePreview( true ); // run immediately on effect change
            } );
            dom.effectGrid.appendChild( btn );
        } );
    }

    // --------------------------------------------------------
    // PREVIEW RENDERER
    // Uses WordDropEffects (effects.js) — same code as the site overlay
    // --------------------------------------------------------
    let previewCtx     = null;
    let previewRunning = false;
    let _previewSafetyTimer = null;

    function getPreviewData() {
        return {
            text:     ( dom.overlayText?.value || '' ).trim() || 'YOUR TEXT',
            font:     state.selectedFont,
            effect:   state.selectedEffect,
            size:     state.selectedSize,
            opacity:  state.opacity,
            gradient: state.gradStart + ',' + state.gradEnd,
        };
    }

    function buildPreviewCtx() {
        const box = dom.previewContainer;
        return {
            container: box,
            textEl:    dom.previewTextEl,
            canvas:    dom.previewCanvas,
            svgSlot:   box,
            get W()        { return box.offsetWidth;  },
            get H()        { return box.offsetHeight; },
            get isMobile() { return false; },
        };
    }

    // Mark preview as done — re-enable replay button
    function _previewDone() {
        previewRunning = false;
        clearTimeout( _previewSafetyTimer );
        if ( dom.previewReplay ) {
            dom.previewReplay.disabled      = false;
            dom.previewReplay.style.opacity = '';
        }
    }

    // Mark preview as running — disable replay button, arm safety valve
    function _previewStart() {
        previewRunning = true;
        clearTimeout( _previewSafetyTimer );
        _previewSafetyTimer = setTimeout( _previewDone, 4000 );
        if ( dom.previewReplay ) {
            dom.previewReplay.disabled      = true;
            dom.previewReplay.style.opacity = '0.3';
        }
    }

    // For CSS-animation effects: unlock as soon as animationend fires on textEl
    function _watchAnimEnd() {
        const textEl = previewCtx?.textEl;
        if ( ! textEl ) return;
        textEl.addEventListener( 'animationend', function onEnd() {
            textEl.removeEventListener( 'animationend', onEnd );
            _previewDone();
        }, { once: true } );
    }

    function runPreview() {
        if ( ! window.WordDropEffects ) {
            _staticPreviewFallback();
            return;
        }
        if ( previewRunning ) return;
        if ( ! previewCtx ) previewCtx = buildPreviewCtx();

        // Guard: container must have layout — defer if not yet painted
        if ( previewCtx.W === 0 ) {
            setTimeout( runPreview, 80 );
            return;
        }

        const FX   = window.WordDropEffects;
        const data = getPreviewData();

        _previewStart();
        FX.clearAll( previewCtx );
        FX.applyStyle( previewCtx, data );
        FX.runIn( previewCtx, data );
        _watchAnimEnd(); // unlocks early for CSS-anim effects; safety valve catches canvas/SVG
    }

    function replayPreview() {
        if ( previewRunning ) return; // guard double-tap
        if ( ! window.WordDropEffects || ! previewCtx ) {
            runPreview();
            return;
        }
        const FX   = window.WordDropEffects;
        const data = getPreviewData();
        _previewStart();
        FX.runOut( previewCtx, data, () => {
            FX.clearAll( previewCtx );
            FX.applyStyle( previewCtx, data );
            FX.runIn( previewCtx, data );
            // Re-arm safety valve for the in-animation
            clearTimeout( _previewSafetyTimer );
            _previewSafetyTimer = setTimeout( _previewDone, 4000 );
            _watchAnimEnd();
        } );
    }

    // Fallback for when effects.js is not available (static gradient text)
    function _staticPreviewFallback() {
        const tEl = dom.previewTextEl;
        const data = getPreviewData();
        const font = FONTS.find( f => f.slug === data.font );
        tEl.textContent = data.text;
        if ( font ) tEl.style.fontFamily = font.family;
        tEl.className = 'preview-text-el wd-size-' + data.size;
        tEl.style.backgroundImage = `linear-gradient(135deg,${ state.gradStart },${ state.gradEnd })`;
        tEl.style.opacity = data.opacity;
    }

    // Debounced wrapper — heavy effects get longer debounce to avoid churn while typing
    let previewDebounce = null;
    function schedulePreview( immediate ) {
        clearTimeout( previewDebounce );
        if ( immediate ) { runPreview(); return; }
        const heavy = [ 'pixel-assemble', 'draw-stroke' ];
        const delay = heavy.includes( state.selectedEffect ) ? 700 : 400;
        previewDebounce = setTimeout( runPreview, delay );
    }

    // Legacy alias — used in init
    function updateLivePreview() { schedulePreview( false ); }

    function updateSliderFill( slider ) {
        const pct = ( ( slider.value - slider.min ) / ( slider.max - slider.min ) ) * 100;
        slider.style.setProperty( '--fill-pct', pct + '%' );
    }

    function updateGradientPreview() {
        dom.gradPreview.style.background =
            `linear-gradient(90deg, ${ state.gradStart }, ${ state.gradEnd })`;
    }

    // Instantly updates just the gradient on the preview text — no effect replay
    function _applyGradientToPreview() {
        if ( ! previewCtx ) return;
        previewCtx.textEl.style.backgroundImage =
            `linear-gradient(135deg, ${ state.gradStart }, ${ state.gradEnd })`;
    }

    // --------------------------------------------------------
    // UI HELPERS
    // --------------------------------------------------------
    function updatePinDots() {
        dom.pinDots.forEach( ( dot, i ) =>
            dot.classList.toggle( 'pin-dot--filled', i < state.pin.length )
        );
    }
    function resetPin()          { state.pin = ''; updatePinDots(); }
    function showLoginError( t ) {
        dom.loginErrorText.textContent = t;
        dom.loginError.hidden          = false;
        dom.loginError.style.animation = 'none';
        void dom.loginError.offsetHeight;
        dom.loginError.style.animation = '';
    }
    function hideLoginError()    { dom.loginError.hidden = true; }

    function showFeedback( text, type ) {
        dom.feedback.className       = `save-feedback save-feedback--${ type }`;
        dom.feedbackText.textContent = text;
        dom.feedback.hidden          = false;
    }
    function hideFeedback()      { dom.feedback.hidden = true; }

    function setLoading( v ) {
        state.isLoading         = v;
        dom.publishBtn.disabled = v;
        dom.publishBtn.classList.toggle( 'save-btn--loading', v );
    }

    // --------------------------------------------------------
    // LOGOUT CONFIRM — inline, no native confirm() dialog
    // --------------------------------------------------------
    function showLogoutConfirm() {
        // Remove any existing confirm
        const existing = document.getElementById( 'wd-logout-confirm' );
        if ( existing ) { existing.remove(); return; }

        const el = document.createElement( 'div' );
        el.id = 'wd-logout-confirm';
        el.innerHTML = `
            <span class="wd-logout-confirm__text">Log out?</span>
            <button class="wd-logout-confirm__yes">Yes</button>
            <button class="wd-logout-confirm__no">Cancel</button>
        `;
        // Insert after logout button
        dom.btnLogout.insertAdjacentElement( 'afterend', el );

        el.querySelector( '.wd-logout-confirm__yes' ).addEventListener( 'click', () => {
            el.remove();
            logout();
        } );
        el.querySelector( '.wd-logout-confirm__no' ).addEventListener( 'click', () => el.remove() );

        // Auto-dismiss after 4s
        setTimeout( () => { if ( el.parentNode ) el.remove(); }, 4000 );
    }

    function logout() {
        clearInterval( pollTimer );
        clearSession();
        showLogin();
    }

    // --------------------------------------------------------
    // EVENTS
    // --------------------------------------------------------
    function bindEvents() {
        dom.keypadBtns.forEach( b =>
            b.addEventListener( 'click', () => handleDigit( b.dataset.digit ) )
        );
        dom.keypadDelete.addEventListener( 'click', handleDelete );

        dom.btnLogout.addEventListener( 'click', () => {
            showLogoutConfirm();
        } );

        dom.overlayText.addEventListener( 'input', () => {
            dom.charCount.textContent = dom.overlayText.value.length + ' / 60';
            updateLivePreview();
        } );

        dom.gradStart.addEventListener( 'input', () => {
            state.gradStart = dom.gradStart.value;
            updateGradientPreview();
            _applyGradientToPreview(); // instant — no effect re-run needed
        } );
        dom.gradEnd.addEventListener( 'input', () => {
            state.gradEnd = dom.gradEnd.value;
            updateGradientPreview();
            _applyGradientToPreview();
        } );

        dom.durBtns.forEach( b => {
            b.addEventListener( 'click', () => {
                state.selectedDur = parseInt( b.dataset.dur, 10 );
                dom.durBtns.forEach( d => d.classList.toggle( 'selected', d === b ) );
            } );
        } );

        dom.sizeBtns.forEach( b => {
            b.addEventListener( 'click', () => {
                state.selectedSize = b.dataset.size;
                dom.sizeBtns.forEach( d => d.classList.toggle( 'selected', d === b ) );
                schedulePreview( true );
            } );
        } );

        dom.opacitySlider.addEventListener( 'input', () => {
            state.opacity = parseInt( dom.opacitySlider.value, 10 ) / 100;
            dom.opacityValue.textContent = dom.opacitySlider.value + '%';
            updateSliderFill( dom.opacitySlider );
            // Update style immediately — no need to re-run full effect for opacity
            if ( previewCtx ) {
                const FX = window.WordDropEffects;
                if ( FX ) {
                    previewCtx.textEl.style.opacity = state.opacity;
                    previewCtx.textEl.style.setProperty( '--wd-opacity', state.opacity );
                }
            }
        } );

        if ( dom.previewReplay ) {
            dom.previewReplay.addEventListener( 'click', replayPreview );
        }

        dom.publishBtn.addEventListener( 'click', handlePublish );
        dom.clearBtn.addEventListener(   'click', handleClear );

        // Fysisk tastatur
        document.addEventListener( 'keydown', e => {
            if ( ! dom.screenLogin.classList.contains( 'screen--active' ) ) return;
            if ( /^\d$/.test( e.key ) )  handleDigit( e.key );
            if ( e.key === 'Backspace' ) handleDelete();
        } );
    }

    // --------------------------------------------------------
    // START
    // --------------------------------------------------------
    init();

} )();
