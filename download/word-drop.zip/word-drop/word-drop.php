<?php
/**
 * Plugin Name: Word Drop
 * Plugin URI:  https://larssohl.dk/worddrop
 * Description: Post dramatic full-screen text overlays to your site from a PWA on your phone.
 * Version:     1.0.4
 * Author:      Lars Sohl
 * Author URI:  https://larssohl.dk
 * License:     GPL-2.0+
 * Text Domain: word-drop
 */

defined( 'ABSPATH' ) || exit;

define( 'WORD_DROP_VERSION', '1.0.4' );
define( 'WORD_DROP_PATH',    plugin_dir_path( __FILE__ ) );
define( 'WORD_DROP_URL',     set_url_scheme( plugin_dir_url( __FILE__ ), 'https' ) );

require_once WORD_DROP_PATH . 'includes/class-auth.php';
require_once WORD_DROP_PATH . 'includes/class-api.php';
require_once WORD_DROP_PATH . 'includes/class-admin.php';
require_once WORD_DROP_PATH . 'includes/class-frontend.php';

add_action( 'plugins_loaded', function () {
    WordDrop_Auth::init();
    WordDrop_API::init();
    WordDrop_Admin::init();
    WordDrop_Frontend::init();
} );

// Activation: set defaults using wp_hash_password — never password_hash()
register_activation_hook( __FILE__, function () {
    if ( ! get_option( 'word_drop_settings' ) ) {
        update_option( 'word_drop_settings', [
            'pin_hash' => wp_hash_password( '1234' ),
        ] );
    }
    if ( ! get_option( 'word_drop_overlay' ) ) {
        update_option( 'word_drop_overlay', [ 'active' => false ] );
    }
} );

register_deactivation_hook( __FILE__, function () {
    update_option( 'word_drop_overlay', [ 'active' => false ] );
} );
