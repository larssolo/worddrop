/**
 * WordDropEffects — portable effect renderer
 *
 * Tager et context-objekt og kører effekter i det.
 * Bruges af både overlay.js (fuld skærm) og preview (lille boks i PWA).
 *
 * ctx = {
 *   container  : HTMLElement  — beholder der indeholder alt
 *   textEl     : HTMLElement  — gradient-tekst element
 *   canvas     : HTMLElement  — <canvas> til pixel-effekt
 *   svgSlot    : HTMLElement  — element SVG appended til (draw-stroke)
 *   W          : number       — container bredde i px
 *   H          : number       — container højde i px
 *   isMobile   : boolean      — om vi er på mobilorienteringen
 * }
 *
 * data = standard overlay-data objekt { text, font, size, gradient, opacity, effect }
 */
window.WordDropEffects = ( function () {
    'use strict';

    // Escape HTML entities so user text never injects markup
    function _esc( str ) {
        return ( str || '' )
            .replace( /&/g, '&amp;' )
            .replace( /</g, '&lt;' )
            .replace( />/g, '&gt;' )
            .replace( /"/g, '&quot;' );
    }


    // ----------------------------------------------------------------
    // Font helpers
    // ----------------------------------------------------------------
    const FONT_MAP = {
        'bebas-neue':       'Bebas Neue',
        'pacifico':         'Pacifico',
        'righteous':        'Righteous',
        'boogaloo':         'Boogaloo',
        'permanent-marker': 'Permanent Marker',
        'playfair-display':  'Playfair Display',
    };

    function getFontFamily( slug ) {
        return FONT_MAP[ slug ] || 'Bebas Neue';
    }

    // ----------------------------------------------------------------
    // Font size — mirrors CSS clamp() values in overlay.css
    // W is container width; on mobile, text is vertical so we size
    // based on W (= vw) for both orientations
    // ----------------------------------------------------------------
    const SIZE_MAP = {
        desktop: { small: 0.08, medium: 0.16, large: 0.28 },
        mobile:  { small: 0.18, medium: 0.32, large: 0.52 },
    };

    function getFontSize( ctx, size ) {
        const map = ctx.isMobile ? SIZE_MAP.mobile : SIZE_MAP.desktop;
        return Math.floor( ctx.W * ( map[ size ] || map.medium ) );
    }

    // ----------------------------------------------------------------
    // Easing
    // ----------------------------------------------------------------
    function easeOutCubic( t ) {
        return 1 - Math.pow( 1 - t, 3 );
    }

    // ----------------------------------------------------------------
    // Gradient helpers
    // ----------------------------------------------------------------
    function parseGradient( gradient ) {
        const parts = ( gradient || '#ffffff,#ffffff' ).split( ',' );
        return {
            c1: parts[0]?.trim() || '#ffffff',
            c2: parts[1]?.trim() || parts[0]?.trim() || '#ffffff',
        };
    }

    // ----------------------------------------------------------------
    // SVG cleanup helper
    // ----------------------------------------------------------------
    function clearSvgFrom( slotEl ) {
        const existing = slotEl.querySelector( '#wd-svg-draw' );
        if ( existing ) existing.remove();
    }

    // ================================================================
    // EFFECT 1: Fade Gradient
    // textEl fades in via CSS animation class
    // ================================================================
    function fadeIn( ctx ) {
        ctx.textEl.style.opacity = '';
        ctx.textEl.classList.add( 'wd-anim-fade-gradient-in' );
    }

    function fadeOut( ctx, done ) {
        ctx.textEl.classList.remove( 'wd-anim-fade-gradient-in' );
        ctx.textEl.classList.add( 'wd-anim-fade-gradient-out' );
        ctx.textEl.addEventListener( 'animationend', done, { once: true } );
    }

    // ================================================================
    // EFFECT 2: Pixel Assemble
    // Canvas owns display lifetime — textEl stays opacity:0
    // ================================================================
    function pixelIn( ctx, data ) {
        // Guard: container must have layout before we read dimensions
        if ( ctx.W === 0 || ctx.H === 0 ) {
            fadeIn( ctx );
            return;
        }
        ctx.textEl.style.opacity = '0';

        const opacity = parseFloat( data.opacity ) || 0.6;
        const { c1, c2 } = parseGradient( data.gradient );
        const fs = getFontSize( ctx, data.size );

        // Size canvas to container
        ctx.canvas.width  = ctx.W;
        ctx.canvas.height = ctx.H;
        const drawCtx = ctx.canvas.getContext( '2d' );

        // Offscreen: on mobile swap W/H to render text upright
        const oW = ctx.isMobile ? ctx.H : ctx.W;
        const oH = ctx.isMobile ? ctx.W : ctx.H;
        const offscreen = document.createElement( 'canvas' );
        offscreen.width  = oW;
        offscreen.height = oH;
        const octx = offscreen.getContext( '2d' );

        const grad = octx.createLinearGradient( 0, 0, oW, oH );
        grad.addColorStop( 0, c1 );
        grad.addColorStop( 1, c2 );

        octx.fillStyle    = grad;
        octx.font         = `${ fs }px '${ getFontFamily( data.font ) }', sans-serif`;
        octx.textAlign    = 'center';
        octx.textBaseline = 'middle';

        // Handle two lines on offscreen canvas — line 2 at 55% of line 1 size
        const lines = ( data.text || '' ).split( '\n' );
        if ( lines.length > 1 && lines[1].trim() !== '' ) {
            const fs2   = fs * 0.55;
            const lineH = fs * 1.05 + fs2 * 0.55; // gap between baselines
            const totalH = fs + fs2;
            const startY = oH / 2 - totalH / 2;
            octx.font = `${ fs }px '${ getFontFamily( data.font ) }', sans-serif`;
            octx.fillText( lines[0], oW / 2, startY + fs * 0.85 );
            octx.font = `${ fs2 }px '${ getFontFamily( data.font ) }', sans-serif`;
            octx.fillText( lines[1], oW / 2, startY + fs + fs2 * 0.85 );
        } else {
            octx.fillText( lines[0] || '', oW / 2, oH / 2 );
        }

        // Extract non-transparent pixels
        const imgData = octx.getImageData( 0, 0, oW, oH );
        const pixels  = [];

        for ( let i = 0; i < imgData.data.length; i += 4 ) {
            if ( imgData.data[ i + 3 ] > 50 ) {
                const px = ( i / 4 ) % oW;
                const py = Math.floor( ( i / 4 ) / oW );

                let tx, ty;
                if ( ctx.isMobile ) {
                    tx = ctx.W - 1 - py;
                    ty = px;
                } else {
                    tx = px;
                    ty = py;
                }

                pixels.push( {
                    tx, ty,
                    sx: Math.random() * ctx.W,
                    sy: Math.random() * ctx.H,
                    r:  imgData.data[ i ],
                    g:  imgData.data[ i + 1 ],
                    b:  imgData.data[ i + 2 ],
                } );
            }
        }

        // Subsample — max 8 000 particles
        const step      = Math.max( 1, Math.floor( pixels.length / 8000 ) );
        const particles = pixels.filter( ( _, i ) => i % step === 0 );

        const DURATION = 2200;
        const start    = performance.now();

        function draw( now ) {
            const progress = Math.min( ( now - start ) / DURATION, 1 );
            const ease     = easeOutCubic( progress );

            drawCtx.clearRect( 0, 0, ctx.W, ctx.H );
            drawCtx.save();
            drawCtx.globalAlpha = opacity;
            for ( const p of particles ) {
                const cx = p.sx + ( p.tx - p.sx ) * ease;
                const cy = p.sy + ( p.ty - p.sy ) * ease;
                drawCtx.fillStyle = `rgb(${ p.r },${ p.g },${ p.b })`;
                drawCtx.fillRect( cx, cy, 2, 2 );
            }
            drawCtx.restore();

            if ( progress < 1 ) requestAnimationFrame( draw );
            // Canvas stays visible — pixelOut will fade it
        }

        requestAnimationFrame( draw );
    }

    function pixelOut( ctx, done ) {
        _fadeOutCanvas( ctx.canvas, 500, done );
    }

    function _fadeOutCanvas( cvs, duration, done ) {
        const drawCtx  = cvs.getContext( '2d' );
        const snapshot = drawCtx.getImageData( 0, 0, cvs.width, cvs.height );
        const start    = performance.now();

        function step( now ) {
            const p = Math.min( ( now - start ) / duration, 1 );
            drawCtx.clearRect( 0, 0, cvs.width, cvs.height );
            drawCtx.save();
            drawCtx.globalAlpha = 1 - p;
            drawCtx.putImageData( snapshot, 0, 0 );
            drawCtx.restore();

            if ( p < 1 ) {
                requestAnimationFrame( step );
            } else {
                drawCtx.clearRect( 0, 0, cvs.width, cvs.height );
                if ( typeof done === 'function' ) done();
            }
        }
        requestAnimationFrame( step );
    }

    // ================================================================
    // EFFECT 3: Draw Stroke
    // SVG owns display lifetime — textEl stays opacity:0
    // ================================================================
    function drawStrokeIn( ctx, data ) {
        clearSvgFrom( ctx.svgSlot );
        ctx.textEl.style.opacity = '0';

        const opacity  = parseFloat( data.opacity ) || 0.6;
        const { c1, c2 } = parseGradient( data.gradient );
        const gradId   = 'wd-grad-' + Date.now();
        const fs       = getFontSize( ctx, data.size );
        const W = ctx.W, H = ctx.H;

        const svg = document.createElementNS( 'http://www.w3.org/2000/svg', 'svg' );
        svg.setAttribute( 'id', 'wd-svg-draw' );
        svg.style.cssText = 'position:absolute;inset:0;width:100%;height:100%;overflow:visible;pointer-events:none;z-index:2;';

        // Gradient def
        const defs    = document.createElementNS( 'http://www.w3.org/2000/svg', 'defs' );
        const linGrad = document.createElementNS( 'http://www.w3.org/2000/svg', 'linearGradient' );
        linGrad.setAttribute( 'id', gradId );
        linGrad.setAttribute( 'x1', '0%' );  linGrad.setAttribute( 'y1', '0%' );
        linGrad.setAttribute( 'x2', '100%' ); linGrad.setAttribute( 'y2', '100%' );
        const s1 = document.createElementNS( 'http://www.w3.org/2000/svg', 'stop' );
        s1.setAttribute( 'offset', '0%' );   s1.setAttribute( 'stop-color', c1 );
        const s2 = document.createElementNS( 'http://www.w3.org/2000/svg', 'stop' );
        s2.setAttribute( 'offset', '100%' ); s2.setAttribute( 'stop-color', c2 );
        linGrad.append( s1, s2 );
        defs.appendChild( linGrad );
        svg.appendChild( defs );

        // Handle two lines via SVG <text> with <tspan>
        const lines = ( data.text || '' ).split( '\n' );
        const lineH = fs * 1.1;

        const svgText = document.createElementNS( 'http://www.w3.org/2000/svg', 'text' );
        svgText.setAttribute( 'x', '50%' );
        svgText.setAttribute( 'dominant-baseline', 'middle' );
        svgText.setAttribute( 'text-anchor', 'middle' );
        svgText.setAttribute( 'font-family', `'${ getFontFamily( data.font ) }', sans-serif` );
        svgText.setAttribute( 'font-size', fs );
        svgText.setAttribute( 'fill', `url(#${ gradId })` );
        svgText.setAttribute( 'fill-opacity', '0' );
        svgText.setAttribute( 'stroke', `url(#${ gradId })` );
        svgText.setAttribute( 'stroke-width', '2' );
        svgText.setAttribute( 'opacity', opacity );

        if ( lines.length > 1 && lines[1].trim() !== '' ) {
            // Line 2 at 55% of line 1 font size
            const fs2    = fs * 0.55;
            const totalH = fs + fs2 + fs * 0.15;
            const y1     = H / 2 - totalH / 2 + fs * 0.5;
            const y2     = y1 + fs * 0.85 + fs2 * 0.5;

            const t1 = document.createElementNS( 'http://www.w3.org/2000/svg', 'tspan' );
            t1.setAttribute( 'x', '50%' );
            t1.setAttribute( 'y', y1 );
            t1.textContent = lines[0];
            svgText.appendChild( t1 );

            const t2 = document.createElementNS( 'http://www.w3.org/2000/svg', 'tspan' );
            t2.setAttribute( 'x', '50%' );
            t2.setAttribute( 'y', y2 );
            t2.setAttribute( 'font-size', fs2 );
            t2.textContent = lines[1];
            svgText.appendChild( t2 );
        } else {
            svgText.setAttribute( 'y', '50%' );
            svgText.textContent = lines[0] || '';
        }

        if ( ctx.isMobile ) {
            svgText.setAttribute( 'transform', `rotate(-90, ${ W / 2 }, ${ H / 2 })` );
        }

        svg.appendChild( svgText );
        ctx.svgSlot.appendChild( svg );

        requestAnimationFrame( () => {
            const len = svgText.getTotalLength ? svgText.getTotalLength() : 5000;
            svgText.style.strokeDasharray  = len;
            svgText.style.strokeDashoffset = len;

            requestAnimationFrame( () => {
                svgText.style.transition       = 'stroke-dashoffset 2s ease-in-out';
                svgText.style.strokeDashoffset = '0';

                setTimeout( () => {
                    svgText.style.transition = 'fill-opacity 0.8s ease';
                    svgText.setAttribute( 'fill-opacity', '1' );

                    setTimeout( () => {
                        svgText.style.transition = 'stroke-width 0.5s ease';
                        svgText.style.strokeWidth = '0';
                    }, 800 );
                }, 1800 );
            } );
        } );
    }

    function drawStrokeOut( ctx, done ) {
        const svg = ctx.svgSlot.querySelector( '#wd-svg-draw' );
        if ( svg ) {
            svg.style.transition = 'opacity 0.6s ease';
            svg.style.opacity    = '0';
            setTimeout( () => { svg.remove(); done(); }, 650 );
        } else {
            done();
        }
    }


    // ================================================================
    // EFFECT 6: Shadow Drift
    // CSS keyframe — drop-shadow filter works on gradient text unlike
    // box-shadow. Shadow starts large/diffuse, settles to a crisp rest.
    // ================================================================
    function shadowDriftIn( ctx ) {
        ctx.textEl.classList.add( 'wd-anim-shadow-drift-in' );
    }

    function shadowDriftOut( ctx, done ) {
        ctx.textEl.classList.remove( 'wd-anim-shadow-drift-in' );
        ctx.textEl.classList.add( 'wd-anim-shadow-drift-out' );
        ctx.textEl.addEventListener( 'animationend', done, { once: true } );
    }

    // ================================================================
    // EFFECT 4: Glitch Burst
    // ================================================================
    function glitchIn( ctx ) {
        ctx.textEl.classList.add( 'wd-anim-glitch-burst-in' );
    }

    function glitchOut( ctx, done ) {
        ctx.textEl.classList.remove( 'wd-anim-glitch-burst-in' );
        ctx.textEl.classList.add( 'wd-anim-glitch-burst-out' );
        ctx.textEl.addEventListener( 'animationend', done, { once: true } );
    }

    // ================================================================
    // EFFECT 5: Liquid Rise
    // clip-path on gradient-text is broken in Chrome so we wrap textEl
    // ================================================================
    function liquidIn( ctx ) {
        // Clean up any existing wrap
        const existing = ctx.container.querySelector( '#wd-liquid-wrap' );
        if ( existing ) {
            if ( ctx.textEl.parentNode === existing ) {
                existing.parentNode.insertBefore( ctx.textEl, existing );
            }
            existing.remove();
        }

        const wrap = document.createElement( 'div' );
        wrap.id = 'wd-liquid-wrap';
        // Mirror the CSS for the full-screen version but scoped to container
        wrap.style.cssText = 'position:absolute;inset:0;overflow:hidden;display:flex;align-items:center;justify-content:center;';
        ctx.textEl.parentNode.insertBefore( wrap, ctx.textEl );
        wrap.appendChild( ctx.textEl );

        requestAnimationFrame( () => wrap.classList.add( 'wd-anim-liquid-rise-in' ) );
    }

    function liquidOut( ctx, done ) {
        const wrap = ctx.container.querySelector( '#wd-liquid-wrap' );
        if ( wrap ) {
            wrap.classList.remove( 'wd-anim-liquid-rise-in' );
            wrap.classList.add( 'wd-anim-liquid-rise-out' );
            wrap.addEventListener( 'animationend', done, { once: true } );
        } else {
            _simpleFadeOut( ctx, done );
        }
    }

    // ----------------------------------------------------------------
    // Generic fallback fade
    // ----------------------------------------------------------------
    function _simpleFadeOut( ctx, done ) {
        ctx.textEl.style.transition = 'opacity 0.5s ease';
        ctx.textEl.style.opacity    = '0';
        setTimeout( () => { ctx.textEl.style.transition = ''; done(); }, 520 );
    }

    // ================================================================
    // PUBLIC API
    // ================================================================
    return {
        /**
         * Run in-effect on ctx with data.
         * Returns a cleanup/cancel function — call it before running another effect.
         */
        runIn( ctx, data ) {
            const effect = data.effect || 'fade-gradient';
            switch ( effect ) {
                case 'fade-gradient':   fadeIn( ctx );           break;
                case 'pixel-assemble':  pixelIn( ctx, data );    break;
                case 'draw-stroke':     drawStrokeIn( ctx, data ); break;
                case 'glitch-burst':    glitchIn( ctx );         break;
                case 'liquid-rise':     liquidIn( ctx );         break;
                case 'shadow-drift':    shadowDriftIn( ctx );    break;
                default:                fadeIn( ctx );
            }
        },

        runOut( ctx, data, done ) {
            const effect = data.effect || 'fade-gradient';
            switch ( effect ) {
                case 'fade-gradient':   fadeOut( ctx, done );        break;
                case 'pixel-assemble':  pixelOut( ctx, done );       break;
                case 'draw-stroke':     drawStrokeOut( ctx, done );  break;
                case 'glitch-burst':    glitchOut( ctx, done );      break;
                case 'liquid-rise':     liquidOut( ctx, done );      break;
                case 'shadow-drift':    shadowDriftOut( ctx, done ); break;
                default:                _simpleFadeOut( ctx, done );
            }
        },

        /** Clear canvas, SVG and liquid wrap from a ctx */
        clearAll( ctx ) {
            // Canvas
            if ( ctx.canvas ) {
                const c = ctx.canvas.getContext( '2d' );
                c.globalAlpha = 1;
                c.clearRect( 0, 0, ctx.canvas.width, ctx.canvas.height );
            }
            // SVG
            clearSvgFrom( ctx.svgSlot );
            // Liquid wrap
            const wrap = ctx.container.querySelector( '#wd-liquid-wrap' );
            if ( wrap ) {
                if ( ctx.textEl.parentNode === wrap ) {
                    wrap.parentNode.insertBefore( ctx.textEl, wrap );
                }
                wrap.remove();
            }
            // Anim classes on textEl
            const prefix = 'wd-anim-';
            [ ...ctx.textEl.classList ]
                .filter( c => c.startsWith( prefix ) )
                .forEach( c => ctx.textEl.classList.remove( c ) );
        },

        /** Prepare textEl with font, size, gradient, opacity */
        applyStyle( ctx, data ) {
            const tEl = ctx.textEl;

            // Two-line support: line 2 is rendered at 55% of line 1 size.
            // We use two <span>s so CSS font-size can differ per line.
            // white-space:pre-wrap on the container handles wrapping within each span.
            const lines = ( data.text || '' ).split( '\n' );
            if ( lines.length > 1 && lines[1].trim() !== '' ) {
                tEl.innerHTML =
                    `<span class="wd-line-1">${ _esc( lines[0] ) }</span>` +
                    `<span class="wd-line-2">${ _esc( lines[1] ) }</span>`;
            } else {
                tEl.innerHTML = `<span class="wd-line-1">${ _esc( lines[0] ) }</span>`;
            }

            // Remove old font/size classes
            [ ...tEl.classList ]
                .filter( c => c.startsWith( 'wd-font-' ) || c.startsWith( 'wd-size-' ) )
                .forEach( c => tEl.classList.remove( c ) );

            tEl.classList.add( 'wd-font-' + ( data.font || 'bebas-neue' ) );
            tEl.classList.add( 'wd-size-' + ( data.size || 'medium' ) );

            const { c1, c2 } = parseGradient( data.gradient );
            tEl.style.backgroundImage = `linear-gradient(135deg, ${ c1 }, ${ c2 })`;

            const opacity = parseFloat( data.opacity ) || 0.6;
            tEl.style.opacity = opacity;
            tEl.style.setProperty( '--wd-opacity', opacity );
        },

        getFontFamily,
        parseGradient,
        getFontSize,
    };

} )();
