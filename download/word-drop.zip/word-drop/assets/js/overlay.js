/**
 * Word Drop — overlay.js
 *
 * Polls /status every 3s. Delegates all rendering to WordDropEffects.
 *
 * Timer logic — per-session countdown:
 *   data.duration = antal sekunder sat af afsenderen (0 = permanent).
 *
 *   Browseren starter SIN EGEN timer (data.duration sekunder) i det øjeblik
 *   den viser overlayet. Det betyder at ALLE besøgende ser overlayet i
 *   det valgte antal sekunder fra DERES første sidevisning — ikke fra
 *   det tidspunkt du trykkede "Post".
 *
 *   Serveren har INGEN automatisk udløb — overlayet forbliver aktivt indtil
 *   det manuelt fjernes via PWA eller admin.
 */
( function () {
    'use strict';

    const CONFIG  = window.WordDropConfig || {};
    const API_URL = CONFIG.apiUrl || '';
    const POLL_MS = 3000;

    const container = document.getElementById( 'word-drop-overlay' );
    const textEl    = document.getElementById( 'word-drop-text-el' );
    const canvas    = document.getElementById( 'word-drop-canvas' );
    const dismiss   = document.getElementById( 'word-drop-dismiss' );

    if ( ! container || ! textEl || ! canvas ) return;

    const FX = window.WordDropEffects;

    if ( ! FX ) {
        console.error( '[WordDrop] WordDropEffects not found — effects.js may have failed to load.' );
        return;
    }

    // Renderer context
    const ctx = {
        container,
        textEl,
        canvas,
        svgSlot:  container,
        get W()        { return container.offsetWidth; },
        get H()        { return container.offsetHeight; },
        get isMobile() { return window.innerWidth <= 768; },
    };

    // ----------------------------------------------------------------
    // State
    // ----------------------------------------------------------------
    let currentData   = null;
    let isVisible     = false;
    let autoHideTimer = null;
    let dismissedAt   = 0;

    // ----------------------------------------------------------------
    // Dismiss button — brugeren afviser overlayet for denne session
    // ----------------------------------------------------------------
    dismiss.addEventListener( 'click', () => {
        dismissedAt = currentData ? currentData.posted_at : Date.now();
        hideOverlay( true );
    } );

    // ----------------------------------------------------------------
    // Polling
    // ----------------------------------------------------------------
    async function poll() {
        try {
            const res  = await fetch( API_URL, { cache: 'no-store' } );
            const data = await res.json();
            handleState( data );
        } catch ( e ) { /* network error — try again next poll */ }
    }

    function handleState( data ) {
        if ( data.active ) {
            // Brugeren har allerede set og afvist dette overlay i denne session
            if ( dismissedAt && data.posted_at && data.posted_at <= dismissedAt ) return;

            const changed = ! currentData ||
                currentData.text      !== data.text      ||
                currentData.effect    !== data.effect    ||
                currentData.font      !== data.font      ||
                currentData.posted_at !== data.posted_at;

            currentData = data;

            if ( ! isVisible || changed ) {
                if ( isVisible ) hideOverlay( false, () => showOverlay( data ) );
                else showOverlay( data );
            }
        } else {
            if ( isVisible ) hideOverlay( false );
            currentData = null;
        }
    }

    // ----------------------------------------------------------------
    // Show
    // ----------------------------------------------------------------
    function showOverlay( data ) {
        clearAutoHide();
        FX.clearAll( ctx );
        FX.applyStyle( ctx, data );

        container.classList.add( 'wd-visible' );
        isVisible = true;

        FX.runIn( ctx, data );

        // Per-session timer — starter fra DEN BESØGENDES sideindlæsning,
        // ikke fra det tidspunkt afsenderen trykkede Post.
        const duration = parseInt( data.duration, 10 );
        if ( duration > 0 ) {
            autoHideTimer = setTimeout( () => {
                // Marker som set — polling må ikke vise dette overlay igen
                // i denne session, selv om serveren stadig har active:true
                dismissedAt = currentData ? currentData.posted_at : Date.now();
                hideOverlay( false );
            }, duration * 1000 );
        }
        // Permanent (duration === 0): vises indtil manuelt fjernet eller siden genindlæses.
    }

    // ----------------------------------------------------------------
    // Hide
    // ----------------------------------------------------------------
    function hideOverlay( immediate, callback ) {
        clearAutoHide();
        if ( ! isVisible ) { if ( callback ) callback(); return; }

        if ( immediate ) {
            container.classList.remove( 'wd-visible' );
            FX.clearAll( ctx );
            isVisible = false;
            if ( callback ) callback();
            return;
        }

        FX.runOut( ctx, currentData || {}, () => {
            container.classList.remove( 'wd-visible' );
            FX.clearAll( ctx );
            isVisible = false;
            if ( callback ) callback();
        } );
    }

    function clearAutoHide() {
        if ( autoHideTimer ) { clearTimeout( autoHideTimer ); autoHideTimer = null; }
    }

    // ----------------------------------------------------------------
    // Start polling — chained setTimeout prevents race conditions:
    // next poll only fires AFTER the current fetch has completed.
    // ----------------------------------------------------------------
    async function scheduledPoll() {
        await poll();
        setTimeout( scheduledPoll, POLL_MS );
    }
    scheduledPoll();

} )();
