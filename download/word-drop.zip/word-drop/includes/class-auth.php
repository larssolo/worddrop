<?php
defined( 'ABSPATH' ) || exit;

/**
 * PIN validation and HMAC token auth.
 * Uses wp_hash_password / wp_check_password — identical to banestatus pattern.
 */
class WordDrop_Auth {

    public static function init() {}

    /**
     * Validate PIN. Returns signed token on success, false on failure.
     */
    public static function validate_pin( string $pin ): string|false {
        if ( $pin === '' ) {
            return false;
        }

        $settings = get_option( 'word_drop_settings' );

        if ( ! is_array( $settings ) || empty( $settings['pin_hash'] ) ) {
            return false;
        }

        // wp_check_password handles both phpass and bcrypt hashes
        if ( ! wp_check_password( $pin, $settings['pin_hash'] ) ) {
            return false;
        }

        return self::generate_token();
    }

    /**
     * Generate HMAC token. Uses WP AUTH_KEY as secret — same as banestatus.
     */
    public static function generate_token(): string {
        $expires = time() + ( 24 * 60 * 60 );
        $payload = base64_encode( $expires . '|word-drop' );
        $sig     = hash_hmac( 'sha256', $payload, self::get_secret() );
        return $payload . '.' . $sig;
    }

    /**
     * Verify token string.
     */
    public static function verify_token( string $token ): bool {
        if ( $token === '' ) {
            return false;
        }

        $parts = explode( '.', $token, 2 );
        if ( count( $parts ) !== 2 ) {
            return false;
        }

        [ $payload, $sig ] = $parts;

        $expected = hash_hmac( 'sha256', $payload, self::get_secret() );
        if ( ! hash_equals( $expected, $sig ) ) {
            return false;
        }

        $decoded = base64_decode( $payload, true );
        if ( $decoded === false ) {
            return false;
        }

        $token_parts = explode( '|', $decoded, 2 );
        if ( count( $token_parts ) !== 2 ) {
            return false;
        }

        [ $expires, ] = $token_parts;

        return time() <= (int) $expires;
    }

    /**
     * Use WordPress AUTH_KEY as HMAC secret — always available, no DB read needed.
     */
    private static function get_secret(): string {
        if ( defined( 'AUTH_KEY' ) && AUTH_KEY !== '' ) {
            return AUTH_KEY;
        }
        if ( defined( 'SECURE_AUTH_KEY' ) && SECURE_AUTH_KEY !== '' ) {
            return SECURE_AUTH_KEY;
        }
        return wp_salt( 'auth' );
    }

    public static function get_token_from_request( WP_REST_Request $request ): string {
        $auth = $request->get_header( 'authorization' );
        if ( $auth && str_starts_with( $auth, 'Bearer ' ) ) {
            return trim( substr( $auth, 7 ) );
        }
        return (string) ( $request->get_param( 'token' ) ?? '' );
    }

    public static function require_token( WP_REST_Request $request ): bool {
        return self::verify_token( self::get_token_from_request( $request ) );
    }
}
