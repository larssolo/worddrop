<?php
defined( 'ABSPATH' ) || exit;

/**
 * Injects the overlay container into the frontend and enqueues assets.
 * Also serves a dynamic config endpoint for the PWA so SITE_URL
 * never needs to be hardcoded in any file.
 */
class WordDrop_Frontend {

    private const FONT_MAP = [
        'bebas-neue'       => 'Bebas+Neue',
        'pacifico'         => 'Pacifico',
        'righteous'        => 'Righteous',
        'boogaloo'         => 'Boogaloo',
        'permanent-marker' => 'Permanent+Marker',
        'playfair-display'  => 'Playfair+Display:ital,wght@0,400;0,700;1,400',
    ];

    public static function init() {
        add_action( 'wp_enqueue_scripts', [ __CLASS__, 'enqueue_assets' ] );
        add_action( 'wp_footer',          [ __CLASS__, 'inject_overlay_markup' ] );
        // Serve dynamic config.js for the PWA — no hardcoding needed
        add_action( 'rest_api_init',      [ __CLASS__, 'register_config_route' ] );
    }

    public static function register_config_route() {
        register_rest_route( 'word-drop/v1', '/pwa-config', [
            'methods'             => 'GET',
            'callback'            => [ __CLASS__, 'serve_pwa_config' ],
            'permission_callback' => '__return_true',
        ] );
    }

    /**
     * Returns a JS snippet that sets WORD_DROP_SITE_URL automatically.
     * The PWA loads this via <script src="..."> so it always has the right URL.
     */
    public static function serve_pwa_config() {
        $site_url = esc_url_raw( get_site_url() );
        header( 'Content-Type: application/javascript; charset=utf-8' );
        header( 'Cache-Control: no-store' );
        echo "window.WORD_DROP_SITE_URL = '" . esc_js( $site_url ) . "';";
        exit;
    }

    public static function enqueue_assets() {
        wp_enqueue_style(
            'word-drop-overlay',
            WORD_DROP_URL . 'assets/css/overlay.css',
            [],
            WORD_DROP_VERSION
        );

        $font_families = implode( '&family=', array_values( self::FONT_MAP ) );
        wp_enqueue_style(
            'word-drop-fonts',
            'https://fonts.googleapis.com/css2?family=' . $font_families . '&display=swap',
            [],
            null
        );

        // effects.js must load before overlay.js
        wp_enqueue_script(
            'word-drop-effects',
            WORD_DROP_URL . 'assets/js/effects.js',
            [],
            WORD_DROP_VERSION,
            true
        );

        wp_enqueue_script(
            'word-drop-overlay',
            WORD_DROP_URL . 'assets/js/overlay.js',
            [ 'word-drop-effects' ],
            WORD_DROP_VERSION,
            true
        );

        wp_localize_script( 'word-drop-overlay', 'WordDropConfig', [
            'apiUrl'  => set_url_scheme( rest_url( 'word-drop/v1/status' ), 'https' ),
            'fontMap' => self::FONT_MAP,
        ] );
    }

    public static function inject_overlay_markup() {
        ?>
        <div id="word-drop-overlay" aria-hidden="true" role="presentation">
            <canvas id="word-drop-canvas"></canvas>
            <div id="word-drop-text-el"></div>
            <button id="word-drop-dismiss" aria-label="Dismiss overlay">✕</button>
        </div>
        <?php
    }
}
