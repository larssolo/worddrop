<?php
defined( 'ABSPATH' ) || exit;

/**
 * REST API endpoints for Word Drop.
 *
 * GET  /wp-json/word-drop/v1/status   — public, polled by site frontend
 * POST /wp-json/word-drop/v1/auth     — PIN → signed token
 * POST /wp-json/word-drop/v1/publish  — push overlay (token required)
 * POST /wp-json/word-drop/v1/clear    — remove overlay (token required)
 */
class WordDrop_API {

    private const NS = 'word-drop/v1';

    private const RATE_LIMIT_MAX    = 5;
    private const RATE_LIMIT_WINDOW = 600; // 10 minutes

    private const ALLOWED_FONTS = [
        'bebas-neue', 'pacifico', 'righteous', 'boogaloo', 'permanent-marker', 'playfair-display',
    ];

    private const ALLOWED_EFFECTS = [
        'fade-gradient', 'pixel-assemble', 'draw-stroke', 'glitch-burst', 'liquid-rise', 'shadow-drift',
    ];

    private const ALLOWED_SIZES = [ 'small', 'medium', 'large' ];

    private const ALLOWED_DURATIONS = [ 0, 5, 10, 15, 20, 30, 45 ];

    public static function init(): void {
        add_action( 'rest_api_init', [ __CLASS__, 'register_routes' ] );
    }

    public static function register_routes(): void {

        register_rest_route( self::NS, '/status', [
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => [ __CLASS__, 'get_status' ],
            'permission_callback' => '__return_true',
        ] );

        register_rest_route( self::NS, '/auth', [
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => [ __CLASS__, 'handle_auth' ],
            'permission_callback' => '__return_true',
            'args'                => [
                'pin' => [
                    'required' => true,
                    'type'     => 'string',
                    // No sanitize_callback — pin must reach wp_check_password unmodified
                ],
            ],
        ] );

        register_rest_route( self::NS, '/publish', [
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => [ __CLASS__, 'handle_publish' ],
            'permission_callback' => [ 'WordDrop_Auth', 'require_token' ],
            'args'                => self::publish_args(),
        ] );

        register_rest_route( self::NS, '/clear', [
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => [ __CLASS__, 'handle_clear' ],
            'permission_callback' => [ 'WordDrop_Auth', 'require_token' ],
        ] );
    }

    // ----------------------------------------------------------------
    // GET /status
    // ----------------------------------------------------------------
    public static function get_status(): WP_REST_Response {
        $overlay = get_option( 'word_drop_overlay', [ 'active' => false ] );

        if ( ! is_array( $overlay ) ) {
            $overlay = [ 'active' => false ];
        }

        // Server-side expiry removed — duration is now a per-session browser timer.
        // Each visitor's browser starts its own countdown when the overlay appears.
        // The overlay stays active on the server until manually cleared via PWA or admin.

        $response = new WP_REST_Response( $overlay );
        $response->header( 'Cache-Control', 'no-store, no-cache, must-revalidate' );
        $response->header( 'Pragma', 'no-cache' );

        return $response;
    }

    // ----------------------------------------------------------------
    // POST /auth
    // ----------------------------------------------------------------
    public static function handle_auth( WP_REST_Request $request ): WP_REST_Response {
        $ip = self::get_client_ip();

        if ( self::is_rate_limited( $ip ) ) {
            return new WP_REST_Response(
                [ 'success' => false, 'message' => 'For mange forsøg. Prøv igen om lidt.' ],
                429
            );
        }

        $pin   = (string) ( $request->get_param( 'pin' ) ?? '' );
        $token = WordDrop_Auth::validate_pin( $pin );

        if ( ! $token ) {
            self::record_failed_attempt( $ip );
            return new WP_REST_Response(
                [ 'success' => false, 'message' => 'Forkert PIN.' ],
                401
            );
        }

        // Success — clear rate limit
        self::clear_rate_limit( $ip );

        // Decode expires from token payload for client session management
        $payload = explode( '.', $token, 2 )[0];
        $decoded = base64_decode( $payload, true );
        $expires = (int) explode( '|', $decoded ?? '', 2 )[0];

        $res = new WP_REST_Response( [
            'success' => true,
            'token'   => $token,
            'expires' => $expires,
        ] );
        $res->header( 'Cache-Control', 'private, no-store' );

        return $res;
    }

    // ----------------------------------------------------------------
    // POST /publish
    // ----------------------------------------------------------------
    public static function handle_publish( WP_REST_Request $request ): WP_REST_Response {
        // sanitize_textarea_field preserves newlines — sanitize_text_field would strip \n
        $text     = sanitize_textarea_field( (string) ( $request->get_param( 'text' ) ?? '' ) );
        $font     = sanitize_key( (string) ( $request->get_param( 'font' ) ?? 'bebas-neue' ) );
        $effect   = sanitize_key( (string) ( $request->get_param( 'effect' ) ?? 'fade-gradient' ) );
        $duration = (int) ( $request->get_param( 'duration' ) ?? 0 );
        $opacity  = (float) ( $request->get_param( 'opacity' ) ?? 0.6 );
        $gradient = sanitize_text_field( (string) ( $request->get_param( 'gradient' ) ?? '#ffffff,#ffffff' ) );
        $size     = sanitize_key( (string) ( $request->get_param( 'size' ) ?? 'medium' ) );

        if ( $text === '' ) {
            return new WP_REST_Response( [ 'success' => false, 'message' => 'Tekst er påkrævet.' ], 400 );
        }

        // Whitelist all inputs
        if ( ! in_array( $font, self::ALLOWED_FONTS, true ) )         $font     = 'bebas-neue';
        if ( ! in_array( $effect, self::ALLOWED_EFFECTS, true ) )     $effect   = 'fade-gradient';
        if ( ! in_array( $size, self::ALLOWED_SIZES, true ) )         $size     = 'medium';
        if ( ! in_array( $duration, self::ALLOWED_DURATIONS, true ) ) $duration = 0;

        $opacity = max( 0.4, min( 0.8, $opacity ) );

        // Validate gradient: must be two valid hex colours
        $parts = array_map( 'trim', explode( ',', $gradient, 2 ) );
        $hex   = '/^#[0-9a-fA-F]{3,8}$/';
        if ( count( $parts ) !== 2 || ! preg_match( $hex, $parts[0] ) || ! preg_match( $hex, $parts[1] ) ) {
            $gradient = '#ffffff,#ffffff';
        }

        update_option( 'word_drop_overlay', [
            'active'     => true,
            'text'       => $text,
            'font'       => $font,
            'effect'     => $effect,
            'size'       => $size,
            'opacity'    => $opacity,
            'gradient'   => $gradient,
            'duration'   => $duration,   // seconds — each visitor's browser starts its own countdown
            'posted_at'  => time(),
        ] );

        return new WP_REST_Response( [ 'success' => true ] );
    }

    // ----------------------------------------------------------------
    // POST /clear
    // ----------------------------------------------------------------
    public static function handle_clear(): WP_REST_Response {
        update_option( 'word_drop_overlay', [ 'active' => false ] );
        $res = new WP_REST_Response( [ 'success' => true ] );
        $res->header( 'Cache-Control', 'no-store' );
        return $res;
    }

    // ----------------------------------------------------------------
    // Helpers
    // ----------------------------------------------------------------
    private static function publish_args(): array {
        return [
            'text'     => [ 'required' => true,  'type' => 'string' ],
            'font'     => [ 'required' => false, 'type' => 'string',  'default' => 'bebas-neue' ],
            'effect'   => [ 'required' => false, 'type' => 'string',  'default' => 'fade-gradient' ],
            'size'     => [ 'required' => false, 'type' => 'string',  'default' => 'medium' ],
            'duration' => [ 'required' => false, 'type' => 'integer', 'default' => 0 ],
            'opacity'  => [ 'required' => false, 'type' => 'number',  'default' => 0.6 ],
            'gradient' => [ 'required' => false, 'type' => 'string',  'default' => '#ffffff,#ffffff' ],
        ];
    }

    private static function get_client_ip(): string {
        foreach ( [ 'HTTP_CF_CONNECTING_IP', 'HTTP_X_FORWARDED_FOR', 'REMOTE_ADDR' ] as $key ) {
            if ( ! empty( $_SERVER[ $key ] ) ) {
                $ip = trim( explode( ',', sanitize_text_field( wp_unslash( $_SERVER[ $key ] ) ) )[0] );
                if ( filter_var( $ip, FILTER_VALIDATE_IP ) ) {
                    return $ip;
                }
            }
        }
        return '0.0.0.0';
    }

    private static function is_rate_limited( string $ip ): bool {
        $data = get_transient( 'word_drop_ratelimit_' . md5( $ip ) );
        return is_array( $data ) && (int) $data['count'] >= self::RATE_LIMIT_MAX;
    }

    private static function record_failed_attempt( string $ip ): void {
        $key  = 'word_drop_ratelimit_' . md5( $ip );
        $data = get_transient( $key );
        $data = is_array( $data ) ? $data : [ 'count' => 0 ];
        $data['count']++;
        set_transient( $key, $data, self::RATE_LIMIT_WINDOW );
    }

    private static function clear_rate_limit( string $ip ): void {
        delete_transient( 'word_drop_ratelimit_' . md5( $ip ) );
    }
}
