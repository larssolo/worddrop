<?php
defined( 'ABSPATH' ) || exit;

class WordDrop_Admin {

    public static function init() {
        add_action( 'admin_menu', [ __CLASS__, 'register_menu' ] );
        add_action( 'admin_post_word_drop_save_settings', [ __CLASS__, 'save_settings' ] );
        add_action( 'admin_post_word_drop_admin_clear', [ __CLASS__, 'ajax_clear' ] );
        add_action( 'admin_post_word_drop_clear_ratelimit', [ __CLASS__, 'clear_ratelimit' ] );
        add_action( 'admin_init', [ __CLASS__, 'ensure_defaults' ] );
    }

    public static function ensure_defaults(): void {
        $settings = get_option( 'word_drop_settings' );

        // get_option returns false if not set — never assume it's an array
        if ( ! is_array( $settings ) ) {
            $settings = [];
        }

        $dirty = false;

        if ( empty( $settings['pin_hash'] ) ) {
            $settings['pin_hash'] = wp_hash_password( '1234' );
            $dirty = true;
        }


        if ( $dirty ) {
            update_option( 'word_drop_settings', $settings );
        }

        // Ensure overlay option exists
        $overlay = get_option( 'word_drop_overlay' );
        if ( ! is_array( $overlay ) ) {
            update_option( 'word_drop_overlay', [ 'active' => false ] );
        }
    }

    public static function register_menu(): void {
        add_menu_page(
            'Word Drop',
            '⚡ Word Drop',
            'manage_options',
            'word-drop',
            [ __CLASS__, 'render_page' ],
            'dashicons-format-status',
            80
        );
    }

    public static function ajax_clear(): void {
        check_admin_referer( 'word_drop_admin_clear' );
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( 'Unauthorized' );
        }
        update_option( 'word_drop_overlay', [ 'active' => false ] );
        wp_redirect( add_query_arg( [ 'page' => 'word-drop', 'cleared' => '1' ], admin_url( 'admin.php' ) ) );
        exit;
    }

    public static function clear_ratelimit(): void {
        check_admin_referer( 'word_drop_clear_ratelimit' );
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( 'Unauthorized' );
        }
        global $wpdb;
        $wpdb->query(
            "DELETE FROM {$wpdb->options}
             WHERE option_name LIKE '_transient_word_drop_ratelimit_%'
             OR option_name LIKE '_transient_timeout_word_drop_ratelimit_%'"
        );
        wp_redirect( add_query_arg( [ 'page' => 'word-drop', 'rate_cleared' => '1' ], admin_url( 'admin.php' ) ) );
        exit;
    }

    public static function save_settings(): void {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( 'Unauthorized' );
        }
        check_admin_referer( 'word_drop_settings' );

        $settings = get_option( 'word_drop_settings' );
        if ( ! is_array( $settings ) ) {
            $settings = [];
        }

        // Read PIN raw — do NOT sanitize_text_field (it trims/strips)
        $new_pin = $_POST['new_pin'] ?? '';
        $new_pin = trim( $new_pin ); // only trim whitespace, nothing else

        if ( strlen( $new_pin ) >= 4 ) {
            $settings['pin_hash'] = wp_hash_password( $new_pin );
            update_option( 'word_drop_settings', $settings );
            wp_redirect( add_query_arg( [ 'page' => 'word-drop', 'saved' => '1' ], admin_url( 'admin.php' ) ) );
        } else {
            update_option( 'word_drop_settings', $settings );
            wp_redirect( add_query_arg( [ 'page' => 'word-drop', 'pin_error' => '1' ], admin_url( 'admin.php' ) ) );
        }
        exit;
    }

    public static function render_page(): void {
        $pwa_url     = WORD_DROP_URL . 'pwa/index.html';
        $saved       = ! empty( $_GET['saved'] );
        $pin_error   = ! empty( $_GET['pin_error'] );
        $rate_cleared = ! empty( $_GET['rate_cleared'] );
        $cleared      = ! empty( $_GET['cleared'] );

        $settings = get_option( 'word_drop_settings' );
        if ( ! is_array( $settings ) ) {
            $settings = [];
        }

        $has_hash   = ! empty( $settings['pin_hash'] );

        // Live diagnostic: test if 1234 would pass right now
        $pin_1234_works = $has_hash && wp_check_password( '1234', $settings['pin_hash'] );
        ?>
        <div class="wrap">
            <h1>⚡ Word Drop</h1>

            <?php if ( $saved ) : ?>
                <div class="notice notice-success is-dismissible"><p>✅ PIN opdateret.</p></div>
            <?php endif; ?>
            <?php if ( $pin_error ) : ?>
                <div class="notice notice-error is-dismissible"><p>⚠️ PIN skal være mindst 4 tegn.</p></div>
            <?php endif; ?>
            <?php if ( $rate_cleared ) : ?>
                <div class="notice notice-success is-dismissible"><p>✅ Rate limit nulstillet — du kan logge ind igen.</p></div>
            <?php endif; ?>
            <?php if ( $cleared ) : ?>
                <div class="notice notice-success is-dismissible"><p>✅ Overlay fjernet.</p></div>
            <?php endif; ?>

            <!-- Diagnostic panel -->
            <div style="background:#fff3cd;border:1px solid #ffc107;border-radius:8px;padding:16px;max-width:900px;margin-top:16px;font-size:13px;">
                <strong>🔍 Diagnostik</strong><br><br>
                PIN hash i DB: <strong><?php echo $has_hash ? '✅ Ja' : '❌ Mangler'; ?></strong><br>
                Virker PIN "1234" lige nu?: <strong><?php echo $pin_1234_works ? '✅ Ja — log ind med 1234' : '❌ Nej — brug Reset-knappen nedenfor'; ?></strong>
            </div>

            <div style="display:grid;grid-template-columns:1fr 1fr;gap:24px;max-width:900px;margin-top:20px;">

                <!-- PWA Access -->
                <div style="background:#fff;border:1px solid #ddd;border-radius:8px;padding:24px;">
                    <h2 style="margin-top:0;">📱 PWA App</h2>
                    <p>Åbn denne URL på din telefon:</p>
                    <code style="display:block;padding:12px;background:#f0f0f0;border-radius:4px;word-break:break-all;font-size:12px;">
                        <?php echo esc_url( $pwa_url ); ?>
                    </code>
                    <a href="<?php echo esc_url( $pwa_url ); ?>" target="_blank" class="button button-primary" style="margin-top:12px;">
                        Åbn PWA →
                    </a>
                    <hr>
                    <p style="font-size:12px;color:#666;">
                        <strong>iOS:</strong> Safari → Del → Føj til hjemmeskærm<br>
                        <strong>Android:</strong> Chrome → ⋮ → Installer app
                    </p>
                </div>

                <!-- PIN Settings -->
                <div style="background:#fff;border:1px solid #ddd;border-radius:8px;padding:24px;">
                    <h2 style="margin-top:0;">🔐 PIN-kode</h2>

                    <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="margin-bottom:20px;">
                        <input type="hidden" name="action" value="word_drop_save_settings">
                        <?php wp_nonce_field( 'word_drop_settings' ); ?>
                        <table class="form-table" style="margin-top:0;">
                            <tr>
                                <th style="padding-top:8px;"><label for="new_pin">Ny PIN</label></th>
                                <td>
                                    <input
                                        type="text"
                                        id="new_pin"
                                        name="new_pin"
                                        class="regular-text"
                                        minlength="4"
                                        placeholder="Min. 4 tegn"
                                        autocomplete="off"
                                        style="letter-spacing:4px;font-size:20px;width:160px;"
                                    >
                                </td>
                            </tr>
                        </table>
                        <?php submit_button( 'Gem ny PIN', 'primary', 'submit', false ); ?>
                    </form>

                    <hr>
                    <p style="font-size:13px;color:#666;margin-bottom:8px;">Reset PIN til <strong>1234</strong>:</p>
                    <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="margin-bottom:12px;">
                        <input type="hidden" name="action" value="word_drop_save_settings">
                        <input type="hidden" name="new_pin" value="1234">
                        <?php wp_nonce_field( 'word_drop_settings' ); ?>
                        <button type="submit" class="button" style="color:#c62828;border-color:#c62828;">
                            🔄 Reset til 1234
                        </button>
                    </form>

                    <hr>
                    <p style="font-size:13px;color:#666;margin-bottom:8px;">Låst ude pga. for mange forsøg:</p>
                    <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                        <input type="hidden" name="action" value="word_drop_clear_ratelimit">
                        <?php wp_nonce_field( 'word_drop_clear_ratelimit' ); ?>
                        <button type="submit" class="button">🔓 Nulstil rate limit</button>
                    </form>
                </div>

            </div>

            <!-- Current overlay status -->
            <?php
            $overlay = get_option( 'word_drop_overlay' );
            $overlay = is_array( $overlay ) ? $overlay : [ 'active' => false ];
            $active  = ! empty( $overlay['active'] );
            ?>
            <div style="background:#fff;border:1px solid #ddd;border-radius:8px;padding:24px;max-width:900px;margin-top:24px;">
                <h2 style="margin-top:0;">📡 Aktivt overlay</h2>
                <?php if ( $active ) : ?>
                    <p>
                        <span style="display:inline-block;width:10px;height:10px;border-radius:50%;background:#00c853;margin-right:6px;"></span>
                        <strong>Aktivt:</strong>
                        "<?php echo esc_html( $overlay['text'] ?? '' ); ?>"
                        &mdash; Font: <?php echo esc_html( $overlay['font'] ?? '' ); ?>
                        &mdash; Effekt: <?php echo esc_html( $overlay['effect'] ?? '' ); ?>
                        <?php
                        $dur = isset( $overlay['duration'] ) ? (int) $overlay['duration'] : 0;
                        if ( $dur > 0 ) {
                            echo '&mdash; Varighed: <em>' . esc_html( $dur ) . ' sek. pr. besøgende</em>';
                        } else {
                            echo '&mdash; <em>Permanent</em>';
                        }
                        ?>
                    </p>
                    <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                        <input type="hidden" name="action" value="word_drop_admin_clear">
                        <?php wp_nonce_field( 'word_drop_admin_clear' ); ?>
                        <button type="submit" class="button button-secondary">🗑 Fjern overlay nu</button>
                    </form>
                <?php else : ?>
                    <p style="color:#999;">Intet aktivt overlay.</p>
                <?php endif; ?>
            </div>
        </div>
        <?php
    }
}
